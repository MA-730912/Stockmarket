# TechLEAPS Pro — Streamlit Cloud Edition (NEW)

Deploy this folder to Streamlit Cloud for an on-demand LEAPS screener dashboard.
- 20 US tech tickers, RSI(14)<30 entry filter
- LEAPS calls (>=365 DTE), delta 0.80–0.90
- Email/Telegram alerts via environment variables
- Charts for RSI trend and delta vs strike

## Deploy
1) Create a GitHub repo, upload all files.
2) Go to https://share.streamlit.io and select the repo and `app.py`.
3) Add Secrets:
```
SMTP_USERNAME=you@gmail.com
SMTP_PASSWORD=your_app_password
SMTP_FROM=you@gmail.com
ALERT_TO=recipient@example.com
TELEGRAM_TOKEN=
TELEGRAM_CHAT=
```
4) Deploy and share your public URL.

## Local run
```
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```
