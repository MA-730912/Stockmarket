
import streamlit as st
import pandas as pd, yaml, datetime as dt, matplotlib.pyplot as plt
from techleaps.screener import Settings, find_entries_and_table
from techleaps.main import load_config
from techleaps.alerts import AlertClient
from techleaps.storage import append_position, read_positions
from techleaps.data import get_price_history, get_option_expirations, get_option_chain
from techleaps.models import solve_iv_call, bs_call_delta

st.set_page_config(page_title="TechLEAPS Pro", layout="wide")
st.title("🚀 TechLEAPS Pro — LEAPS Screener (RSI<30, Δ 0.80–0.90)")

cfg = load_config("config.yaml")
settings = Settings(
    rsi_length=cfg["rsi"]["length"],
    rsi_oversold=cfg["rsi"]["oversold"],
    leaps_min_days=cfg["leaps"]["min_days"],
    delta_min=cfg["delta_target"]["min"],
    delta_mid=cfg["delta_target"]["mid"],
    delta_max=cfg["delta_target"]["max"],
    default_iv=cfg["misc"]["default_iv"],
    take_profit_pct=cfg["risk"]["take_profit_pct"],
)

# Top summary
c1, c2, c3 = st.columns([2,1,1])
with c1: st.subheader("Universe"); st.write(", ".join(cfg["tickers"]))
with c2: st.metric("RSI Oversold", f"< {cfg['rsi']['oversold']}")
with c3: st.metric("Delta Target", f"{cfg['delta_target']['min']}–{cfg['delta_target']['max']} (aim {cfg['delta_target']['mid']})")

st.divider()

# Run Screener Now
st.subheader("Run Screener")
send_alerts = st.checkbox("Send entry alerts", value=False)
auto_add = st.checkbox("Add entries to open_positions.csv", value=False)

if st.button("Scan Now", type="primary"):
    entries, table = find_entries_and_table(cfg["tickers"], settings)
    if table is None or table.empty:
        st.info("No data / no signals.")
    else:
        st.dataframe(table, use_container_width=True)
        if send_alerts and entries:
            ac = AlertClient(cfg)
            for e in entries:
                subj = f"LEAPS ENTRY: {e['ticker']} {e['expiry']} {e['strike']}"
                msg = (f"Ticker: {e['ticker']}\nExpiry: {e['expiry']}\nStrike: {e['strike']}\n"
                       f"Entry (mid): {e['entry_mid']}\nDelta band: {cfg['delta_target']['min']}–{cfg['delta_target']['max']}\n"
                       f"Note: {e['note']}")
                ac.send(subj, msg)
            st.success(f"Sent {len(entries)} entry alert(s).")
        if auto_add and entries:
            cache_dir = cfg.get("misc",{}).get("data_cache_dir",".cache")
            for e in entries: append_position(cache_dir, e)
            st.success(f"Added {len(entries)} entry(ies) to open_positions.csv.")

st.divider()

# Analytics & Charts
left, right = st.columns(2)

with left:
    st.subheader("RSI(14) Trend")
    tkr = st.selectbox("Ticker", cfg["tickers"], index=0, key="tkr_rsi")
    bars = st.slider("History (days)", 60, 500, 250, 10)
    ph = get_price_history(tkr, days=bars)
    if ph is None or ph.empty or "Close" not in ph.columns:
        st.warning("No price data.")
    else:
        close = ph["Close"]
        delta = close.diff()
        gain = (delta.where(delta > 0, 0)).rolling(settings.rsi_length).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(settings.rsi_length).mean()
        rs = gain / (loss.replace(0, 1e-9))
        rsi_series = 100 - (100 / (1 + rs))
        fig, ax = plt.subplots(figsize=(7,3))
        ax.plot(rsi_series.index, rsi_series.values)
        ax.axhline(settings.rsi_oversold, linestyle="--")
        ax.set_title(f"{tkr} — RSI({settings.rsi_length})"); ax.set_ylabel("RSI"); ax.set_xlabel("Date")
        st.pyplot(fig, use_container_width=True)

with right:
    st.subheader("LEAPS Option Chain & Delta Band")
    tkr2 = st.selectbox("Ticker (chain)", cfg["tickers"], index=0, key="tkr_chain")
    expiries = get_option_expirations(tkr2)
    if not expiries:
        st.warning("No expiries available.")
    else:
        today = dt.date.today()
        leaps_exps = []
        for e in expiries:
            try:
                ed = dt.datetime.strptime(e, "%Y-%m-%d").date()
                if (ed - today).days >= settings.leaps_min_days:
                    leaps_exps.append((e, ed))
            except: pass
        if not leaps_exps:
            st.warning("No LEAPS expiries (>= min_days).")
        else:
            leaps_exps.sort(key=lambda x:x[1])
            exp_sel = st.selectbox("Expiry (LEAPS)", [e for e,_ in leaps_exps], index=0)
            chain = get_option_chain(tkr2, exp_sel)
            calls = getattr(chain, "calls", None)
            if calls is None or calls.empty:
                st.warning("No calls for this expiry.")
            else:
                st.caption("Calls (first 50)")
                st.dataframe(calls[["contractSymbol","strike","bid","ask","lastPrice","volume","openInterest"]].head(50), use_container_width=True, height=260)

                spot = float(get_price_history(tkr2, days=5)["Close"].iloc[-1])
                dte_days = (dt.datetime.strptime(exp_sel, "%Y-%m-%d").date() - today).days
                T = max(dte_days, 1)/365.0; r=0.045; q=0.0
                deltas = []
                for _, row in calls.iterrows():
                    K = float(row.get("strike"))
                    bid = row.get("bid"); ask = row.get("ask"); last = row.get("lastPrice")
                    mid = 0.5*(bid+ask) if pd.notna(bid) and pd.notna(ask) and bid>0 and ask>0 else (float(last) if pd.notna(last) and last>0 else None)
                    if mid is None: continue
                    iv = solve_iv_call(mid, spot, K, r, q, T, guess=0.30) or 0.30
                    d  = bs_call_delta(spot, K, r, q, iv, T)
                    deltas.append((K, d))
                if deltas:
                    df_d = pd.DataFrame(deltas, columns=["strike","est_delta"]).sort_values("strike")
                    fig2, ax2 = plt.subplots(figsize=(7,3))
                    ax2.plot(df_d["strike"], df_d["est_delta"])
                    ax2.axhspan(cfg["delta_target"]["min"], cfg["delta_target"]["max"], alpha=0.2)
                    ax2.set_title(f"{tkr2} — Est. Delta vs Strike ({exp_sel})")
                    ax2.set_xlabel("Strike"); ax2.set_ylabel("Estimated Delta")
                    st.pyplot(fig2, use_container_width=True)
                else:
                    st.caption("Could not compute deltas for this expiry.")
