import os, yaml, re, time, pandas as pd
from .screener import screen_tickers, Settings, find_entries_and_table
from .storage import append_position, read_positions
from .alerts import AlertClient
from .data import get_option_chain
from .risk import ExitRule

def _env(s):
    if isinstance(s, str):
        return re.sub(r"\$\{([^}]+)\}", lambda m: os.environ.get(m.group(1), ""), s)
    return s

def _walk_env(x):
    if isinstance(x, dict): return {k: _walk_env(v) for k,v in x.items()}
    if isinstance(x, list): return [_walk_env(i) for i in x]
    return _env(x)

def load_config(path: str) -> dict:
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)
    return _walk_env(cfg)
