import smtplib, ssl, requests
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
class AlertClient:
    def __init__(self, cfg: dict):
        self.cfg=cfg or {}; self.email=(self.cfg.get("alerts") or {}).get("email") or {}; self.telegram=(self.cfg.get("alerts") or {}).get("telegram") or {}
    def send(self, subject:str, message:str):
        if self.email.get("enabled"):
            try: self._send_email(subject,message); print("[alert] email sent")
            except Exception as e: print(f"[alert] email failed: {e}")
        if self.telegram.get("enabled"):
            try: self._send_telegram(f"*{subject}*\n{message}"); print("[alert] telegram sent")
            except Exception as e: print(f"[alert] telegram failed: {e}")
    def _send_email(self, subject:str, message:str):
        host=self.email.get("smtp_host"); port=int(self.email.get("smtp_port",587)); user=self.email.get("username"); password=self.email.get("password")
        sender=self.email.get("from_addr",user); to_addrs=self.email.get("to_addrs",[])
        if isinstance(to_addrs,str): to_addrs=[to_addrs]
        if not (host and user and password and to_addrs): raise ValueError("Email config incomplete")
        msg=MIMEMultipart(); msg["From"]=sender; msg["To"]=", ".join(to_addrs); msg["Subject"]=subject; msg.attach(MIMEText(message,"plain"))
        ctx=ssl.create_default_context()
        with smtplib.SMTP(host,port,timeout=20) as s:
            s.starttls(context=ctx); s.login(user,password); s.sendmail(sender,to_addrs,msg.as_string())
    def _send_telegram(self, text:str):
        token=self.telegram.get("bot_token"); chat_id=self.telegram.get("chat_id")
        if not (token and chat_id): raise ValueError("Telegram config incomplete")
        url=f"https://api.telegram.org/bot{token}/sendMessage"; payload={"chat_id":chat_id,"text":text,"parse_mode":"Markdown"}
        r=requests.post(url,json=payload,timeout=10)
        if r.status_code!=200: raise RuntimeError(f"Telegram API error {r.status_code}: {r.text}")
