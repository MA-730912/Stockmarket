import datetime as dt, pandas as pd, yfinance as yf
from .utils import Retry
def get_price_history(ticker:str, days:int=400)->pd.DataFrame:
    end=dt.date.today(); start=end-dt.timedelta(days=days*2//1)
    df=yf.download(ticker, start=start, end=end, auto_adjust=True, progress=False)
    return df if df is not None else pd.DataFrame()
@Retry(tries=3,delay=1.0)
def get_option_expirations(ticker:str): return yf.Ticker(ticker).options
@Retry(tries=3,delay=1.0)
def get_option_chain(ticker:str, expiry:str): return yf.Ticker(ticker).option_chain(expiry)
