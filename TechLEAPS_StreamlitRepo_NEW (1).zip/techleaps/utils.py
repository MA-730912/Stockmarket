import time, datetime as dt
class Retry:
    def __init__(self, tries=3, delay=1.0): self.tries, self.delay = tries, delay
    def __call__(self, fn):
        def wrapped(*a, **k):
            for i in range(self.tries):
                try: return fn(*a, **k)
                except Exception:
                    if i == self.tries - 1: raise
                    time.sleep(self.delay)
        return wrapped
