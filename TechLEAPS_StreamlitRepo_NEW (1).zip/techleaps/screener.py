import datetime as dt, pandas as pd
from dataclasses import dataclass
from .data import get_price_history, get_option_expirations, get_option_chain
from .indicators import rsi
from .models import solve_iv_call, bs_call_delta
from .risk import ExitRule, target_exit_price

@dataclass
class Settings:
    rsi_length:int; rsi_oversold:float; leaps_min_days:int
    delta_min:float; delta_mid:float; delta_max:float; default_iv:float; take_profit_pct:float

def screen_tickers(tickers, settings:Settings)->pd.DataFrame:
    rows=[]; today=dt.date.today()
    for t in tickers:
        prices=get_price_history(t, days=400)
        if prices is None or prices.empty or "Close" not in prices.columns: continue
        close=prices["Close"]; rsi_series=rsi(close, settings.rsi_length)
        latest_rsi=rsi_series.to_numpy()[-1].item()
        if latest_rsi>=settings.rsi_oversold:
            rows.append({"ticker":t,"signal":"No","rsi":round(latest_rsi,2),"note":"RSI not oversold"}); continue
        expiries=get_option_expirations(t)
        if not expiries: rows.append({"ticker":t,"signal":"Yes","rsi":round(latest_rsi,2),"note":"No expiries"}); continue
        valid=[]
        for e in expiries:
            try:
                ed=dt.datetime.strptime(e,"%Y-%m-%d").date(); dte=(ed-today).days
                if dte>=settings.leaps_min_days: valid.append((e,ed,dte))
            except: pass
        if not valid: rows.append({"ticker":t,"signal":"Yes","rsi":round(latest_rsi,2),"note":"No LEAPS expiries"}); continue
        valid.sort(key=lambda x:x[2]); exp_str,exp_date,dte_days=valid[0]; T=dte_days/365.0
        chain=get_option_chain(t,exp_str); calls=getattr(chain,"calls",None)
        if calls is None or len(calls)==0: rows.append({"ticker":t,"signal":"Yes","rsi":round(latest_rsi,2),"expiry":exp_str,"note":"No calls"}); continue
        spot=float(close.iloc[-1]); r=0.045; q=0.0
        cands=[]
        for _,row in calls.iterrows():
            K=float(row.get("strike")); bid=row.get("bid"); ask=row.get("ask"); last=row.get("lastPrice")
            mids=[x for x in [bid,ask,last] if pd.notna(x) and x>0]
            if not mids: continue
            mid=0.5*(bid+ask) if pd.notna(bid) and pd.notna(ask) and bid>0 and ask>0 else (float(last) if pd.notna(last) and last>0 else None)
            if mid is None: continue
            iv=solve_iv_call(mid, spot, K, r, q, T, guess=0.30) or 0.30
            delta=bs_call_delta(spot, K, r, q, iv, T)
            if settings.delta_min<=delta<=settings.delta_max: cands.append((abs(delta-settings.delta_mid),K,mid,delta,iv))
        if not cands: rows.append({"ticker":t,"signal":"Yes","rsi":round(latest_rsi,2),"expiry":exp_str,"note":"No 0.80–0.90 delta calls"}); continue
        cands.sort(key=lambda x:x[0]); _,K_sel,mid_sel,delta_sel,iv_sel=cands[0]; tp=target_exit_price(mid_sel, ExitRule(settings.take_profit_pct))
        rows.append({"ticker":t,"signal":"Yes","rsi":round(latest_rsi,2),"expiry":exp_str,"strike":round(K_sel,2),"est_delta":round(delta_sel,3),"est_iv":round(iv_sel,3),"mid_price":round(mid_sel,2),"take_profit":round(tp,2),"note":"LEAPS call ~0.85 delta"})
    out=pd.DataFrame(rows)
    if not out.empty:
        out["signal_rank"]=out["signal"].apply(lambda s: 0 if s=="Yes" else 1)
        out=out.sort_values(["signal_rank","ticker"]).drop(columns=["signal_rank"])
    return out

def find_entries_and_table(tickers, settings:Settings):
    table=screen_tickers(tickers, settings); entries=[]
    if table is not None and not table.empty:
        for _,r in table.iterrows():
            if str(r.get("signal"))=="Yes" and r.get("strike") and r.get("mid_price"):
                entries.append({"ticker":r.get("ticker"),"expiry":r.get("expiry"),"strike":float(r.get("strike")),"entry_mid":float(r.get("mid_price")),"take_profit":float(r.get("take_profit")),"note":r.get("note") or ""})
    return entries, table
