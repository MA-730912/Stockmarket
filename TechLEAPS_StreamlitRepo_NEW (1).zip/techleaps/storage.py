import os, csv, datetime as dt
FIELDS=["timestamp","ticker","expiry","strike","entry_mid","take_profit","note"]
def positions_path(cache_dir:str)->str:
    os.makedirs(cache_dir, exist_ok=True); return os.path.join(cache_dir, "open_positions.csv")
def append_position(cache_dir:str,row:dict):
    path=positions_path(cache_dir); file_exists=os.path.exists(path)
    with open(path,"a",newline="") as f:
        w=csv.DictWriter(f, fieldnames=FIELDS)
        if not file_exists: w.writeheader()
        r={k:row.get(k) for k in FIELDS}; 
        r["timestamp"]=r.get("timestamp") or dt.datetime.utcnow().isoformat(); w.writerow(r)
def read_positions(cache_dir:str):
    path=positions_path(cache_dir); 
    if not os.path.exists(path): return []
    with open(path,"r",newline="") as f: return list(csv.DictReader(f))
