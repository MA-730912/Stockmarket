from dataclasses import dataclass
@dataclass
class ExitRule: take_profit_pct: float = 0.10
def target_exit_price(entry_price: float, rule: ExitRule) -> float: return entry_price*(1.0+rule.take_profit_pct)
