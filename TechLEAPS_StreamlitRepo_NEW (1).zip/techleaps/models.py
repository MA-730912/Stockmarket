import math
def _phi(x): return (1.0 / math.sqrt(2 * math.pi)) * math.exp(-0.5*x*x)
def _Phi(x): return 0.5 * (1 + math.erf(x / math.sqrt(2)))
def bs_call_price(S,K,r,q,sigma,T):
    if T<=0 or sigma<=0: return max(0.0, S*math.exp(-q*T)-K*math.exp(-r*T))
    d1=(math.log(S/K)+(r-q+0.5*sigma*sigma)*T)/(sigma*math.sqrt(T)); d2=d1-sigma*math.sqrt(T)
    return S*math.exp(-q*T)*_Phi(d1)-K*math.exp(-r*T)*_Phi(d2)
def bs_call_delta(S,K,r,q,sigma,T):
    if T<=0 or sigma<=0: return 1.0 if S>K else 0.0
    d1=(math.log(S/K)+(r-q+0.5*sigma*sigma)*T)/(sigma*math.sqrt(T)); return math.exp(-q*T)*_Phi(d1)
def bs_vega(S,K,r,q,sigma,T):
    if T<=0 or sigma<=0: return 0.0
    d1=(math.log(S/K)+(r-q+0.5*sigma*sigma)*T)/(sigma*math.sqrt(T)); return S*math.exp(-q*T)*_phi(d1)*math.sqrt(T)
def solve_iv_call(target_price,S,K,r,q,T,guess=0.30,tol=1e-4,max_iter=50):
    sigma=max(1e-4,guess)
    for _ in range(max_iter):
        price=bs_call_price(S,K,r,q,sigma,T); diff=price-target_price
        if abs(diff)<tol: return max(1e-4,sigma)
        vega=bs_vega(S,K,r,q,sigma,T)
        if vega<1e-8: break
        sigma-=diff/vega
        if not (1e-4<=sigma<=5.0): sigma=min(max(sigma,1e-4),5.0)
    return None
